# sanskritayam/__main__.py
from .sanskritayam import main

if __name__ == "__main__":
    main()